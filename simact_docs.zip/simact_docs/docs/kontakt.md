Wenn Sie mehr von mir erfahren möchten schauen Sie doch gerne hier vorbei:

 * [Projkete, CV etc.](http://me.simact.de)
 * [Github Repro](https://github.com/CesMak)
 * [Linked-In](https://www.linkedin.com/in/markus-lamprecht-b0964a160/)

oder kontaktieren Sie mich direkt unter:

MarkusLamprecht@live.de

PS: Ich studiere an der TU Darmstadt, d.h. wenn Sie mich persönlich kennen lernen wollen ist das sicher kein Problem :) 
