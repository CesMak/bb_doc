Direkt zum Engine geht es **[hier](http://simact.de/engine/Engine/engine.html)**.

Der Engine ist sozusagen ein Matlab oder Oktave ähnliches Programm mit dem man **online** regelungstechnische Aufgaben lösen kann. Dabei können einfache symbolische Matrizen Rechnungen wie zum Beispiel um eine Übertragungsmatriz auszurechnen oder auch graphische Methoden:

 * Bode Diagramm (Frequenzkennlinien Verfahren)
 * Nyquist Ortskurve
 * Wurzelortskurve

getestet werden. 

Der Engine baut auf der symbolischen mathematischen [Algebrite Bibliothek](http://algebrite.org/) auf. Die Algebrite Bibliothek wird dabei durch die [simact Bibliothek](https://github.com/CesMak/simact) erweitert, sodass auch regelungstechnische Aufgaben gelöst werden können. 

Der Engine besteht aus:

 * **[Dem engine selbst](http://simact.de/engine/Engine/engine.html)**
 * [Beispiel-Seiten](http://simact.de/engine/Engine/engine_help.html) die zeigen wie man zum Beispiel ein BodeDiagramm plottet
 * [Dokumentation](http://simact.de/engine/doc/global.html) der Funktionen die der Engine bietet
 * [Fertige-Formen](http://www.simact.de/engine/Forms/State_Space_Form/index.html) übersichtliche Berechnungen eines Zustandsraummodelles oder ähnliches.
