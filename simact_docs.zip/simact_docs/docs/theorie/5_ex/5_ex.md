Diese Seite findet sich aktuell noch in Bearbeitung. Die folgenden genannten Überschriften sind die Themen um die es hier gehen wird.

## Ballbot
* [Aufbau und Regelung eines Ballbots.pdf](www.google.de)
* [Präsentation.pdf](www.google.de)
* [Ballbot - 3D Gazebo Simulation - Github](http://github.com/CesMak/bb)

Der Ballbot wurde mit einem Riccati Regeler geregelt.

## Ball on Plate

### Anforderungen an die Kamera
* mind. 60fps entspricht ca. 17ms.
* Totzeit zw. Bildaufnahme und Ausgabe Position nur max. 10ms.
	+ schnelle Bildverarbeitung (5ms.)
	+ schnelle Bildübertragung (5ms.)
* möglichst große Bildauflösung (je höher desto größer Zeit der Bildübertragung

--> wähle Intel Real Sense?

Diagonaler Sichtwinkel der Kamera z.B. 78°
lässt sich mittels Seitenverhältnisses (Bildbreite 16 zu Bidhöhe 9) in horizontalen und vertikalen Sichtwinkel umrechnen. Horizontaler Blickwinkel von 70.42°, vertikaler Blickwinkel von 43,3°
siehe auch Lochkamera Modell?

--> Kamera höhe so einstellen, dass Platte perfekt ausgedeckt ist.

--> Wenn bsp. eine Auflösung von 960x720 gewählt wurde kann für eine quadratische Platte effektive eine Größe von 720x720 Pixel verwendet werden.

--> Kamera-Justierung: Kamera-Höhe eingeben, Platte gerade so dass Mittelpunkt genau unter Linsenmittelpunkt ist, Beleuchtungsverhältnisse beachten!

### Aufbau
* weiße Kugel (einfach weißen Tischtennisball (vorerst))
* schwarze Holzplatte mit Knüppel (rund oder quadratisch?) 
* Platte mit Knüppel 3D drucken?

### Kreiserkennung
* --> evtl. mit Matlab realisieren?
* Ball radius bekannt? (vorerst ja -> ist wichtig um den z Abstand und die x,y Koordinaten zu bestimmen)
* Kamera - Transformationsmatrizen bekannt?! (so wie bei realsense!)
* Verfahren
	+ mach bw, Canny Edge und dann Hough Transformation (130ms)
	+ oder nutze opencv und finde Kreise mit min enclosing circle(??ms)
	+ Matlab PixelschwerpunktVerfahren bwlabeln (28ms)
	+ eigenes Verfahren dass je nach Rotwert entweder den Punkt zu 1 oder zu 0 macht sodass ein binäres Bild entsteht (3D-Matrix -> 2D Matrix) *wichtig: Beachte Beleuchtungsverhältnisse!*
* Pixelmittelpunkt (nur eines Kreises) erkennen durch zählen der 1 Werte je Spalte und Zeile
* Ist es möglich nur Ausschnitte des aktuell aufgenommen Bildes zu übertragen also quasi nur die ROI wenn man weiß wo der Ball ist?

### Positionsbestimmung
* mit "normalem Kalmanfilter" (auch mehrere Bälle sollen bestimmt werden können) (px, py, vx, vy, schätzen) (für werfen auch noch pz,vz schätzbar?)
* mit EKF (besser für Beschleunigte Bewegungen) einfach Linearisierung in jedem Schritt.
* Sensordatenfusion aus Kamerabild und Kraftmessung! (geht nur wenn nur 1 Ball vorhanden ist oder?)
* suche Ball zunächst in gewissem Radius wo er vorher gefunden wurde! -> schätze also neue Position und suche dort zunächst den Ball! dadurch muss nicht Hough Circle Transformation auf gesamtes Bild angewendet werden. Nutze hierfür die Region of Interest (ROI) Funktion
* Positionsbestimmung bei *geneigter* Platte besonders beachten!


## Drei-Tank-System

## Verladebrücke

## Inverses Pendel



