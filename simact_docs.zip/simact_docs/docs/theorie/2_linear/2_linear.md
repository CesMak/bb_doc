In diesem Kapitel geht es um generelle Konzepte der Linearen Regelungstechnik. 
## Mehrgrößenregelung
### Vollständige Modale Synthese
### Falb Wolovich
### Riccati Regler
### Beobachter
### reduzierter Beobachter
### Störgrößen Beobachter


## Modellbildung
Dieses Kapitel bietet eine kurze Zusammenfassung der Modellierung mechanischer & elektrischer Systeme. 
### Potentialvariable und Flussvariable
Mit der Potentialvariale$e_i(t)$und der Flussvariable$f_i(t)$gilt für die verallgemeinterte Leistung: 

$$
P_i(t) = e_i(t) \cdot f_i(t) 
$$

Für ein System gilt generell:$\sum_{i=1}^n P_i(t) = 0$

### Reihen und Parallelschaltung
|Schaltungsart|Gesetze|Wiederstand|Kapazität|Induktivität|
|-----|-----|----|----|----|
| Reihen-<br>schaltung |$f_1=f_2=...=f_n$<br> $\sum e_i =0 \quad (8)$<br> mit (8) Maschengleichung <br> <br> für elektrisches Beispiel rechts gilt: <br>$f=f_1=f_2 \rightarrow I=I_1=I_2$<br>$e=e_1+e_2 \rightarrow U=U_1+U_2$<br>ableiten:$\dot{I}=Q$<br>$\rightarrow Q=Q_1=Q_2$| ![img](R_reihe.png) <br>$U=I\cdot (R_1+R_2)$<br>$R_{ges}=R_1+R_2$|![img](C_reihe.png) <br>$Q=C\cdot U$<br>$U=\frac{Q_{ges}}{C_{ges}}=\frac{Q_1}{C_1}+\frac{Q_2}{C_2}$<br>$\frac{1}{C_{ges}}=\frac{1}{C_1}+\frac{1}{C_2}$<br>$C_{ges}=\frac{C_1\cdot C_2}{C_1+C_2}$|![img](L_reihe.png)<br>$L_{ges} = L_1+L_2$|
| Parallel-<br>schaltung |$e_1=e_2=...=e_n$<br> $\sum f_i =0 \quad (9)$<br> mit (9) Knotengleichung <br> <br> für elektrisches Beispiel rechts gilt: <br>$f=f_1+f_2 \rightarrow I=I_1+I_2$<br>$e=e_1=e_2 \rightarrow U=U_1=U_2$| ![img](R_parallel.png) <br>$R_{ges}=\frac{R_1 \cdot R_2}{R_1+R_2}$|![img](C_parallel.png) <br>$C_{ges}=C_1+C_2$|![img](L_parallel.png) <br>$L_{ges}=\frac{L_1 \cdot L_2}{L_1+L_2}$|


Für den elektrischen Fall bedeutet:

* (8) Die Summe aller Spannungen in einem Kreis ist 0.
* (9) Die Summe aller Zufließenden Ströme eines Knotens ist gleich der Summe aller abfließenden Ströme eines Knotens.

Hierbei ist im elektrischen Fall die Potentialvariable e(t) gleich der Spannung U und die Flussvariable f(t) gleich dem Strom I. Für mechanische bzw. hydraulische etc. Systeme kann ebenfalls eine Potentialvariable und Flussvariable festgelegt werden(siehe nachfolgende Tabelle). Zudem kann beispielswiese für den mechanischen Fall auch ein verallgemeinerter Wiederstand, Kapazität und Induktivität angegeben werden. Hiermit lassen sich mechanische Systeme mit der verallgemeinerten Netzwerkanalyse in Systeme mit "elektrischen Bauelmenten: R, L, C, Stromquelle, Spannungsquelle" überführen und anschließend mit den Konten und Maschengesetzen der Elektrotechnik analysieren.

<!-- 
|  System | Potentialvariable$e_i(t)$ | Flussvariable$f_i(t)$ | Wiederstand |Kapazität   | Induktivität  |
|---|---|---|---|---|---|
|  elektrisch | U  | I  | R  | C  | L  |
|  mechanisch translat. | v  | F   | 1/r (Dämpfer) <br> **1 |  m |  1/c (Feder) |
|  mechanisch rotatorisch |$\omega$ | M  |  1/d (z.B. Last an Welle) | J  | 1/c  |
|  hydraulisch |  p(Druck) | $\dot{V} \stackrel{\rho=const}{=}\dot{m}$| z.B. eine Drossel  | Volumenspeicher <br> z.B. ein Tank | lange Leitung <br> als Trägheit  |
|  pneumatisch<br> e f keine Leistung |  p(Druck) | $\dot{V}$<br> Gasmassenstrom | [R]=1/ms  | [C]=kgm²/N (Masse/Druck) | - - |
|  thermisch<br> e f keine Leistung | [T]=K| $\dot{Q}$Wärmestrom/Energiestrom<br> ist eine Leistung  | [R]=K/W Wärmewiederstand  | [C]=Ws/K Wärmekapazität  | - -  |


### Anmerkungen zur Tabelle:
 * **1: Ein Dämpfer mit Wert b eines mechanischen Systems kann bei der verallgemeinerten Netzwerkanalyse als Wiederstand mit dem Wert 1/b dargestellt werden.
 * Potentialvariablen stellen verallgemeinterte Spannungsquellen dar (bei entsprechenden Randbedingungen). So wird beispielsweise eine Temperatur Randbedingung    in einem verallgemeinerten Netzwerk als Spanungsquelle dargestellt.
 * Flussvariablen stellen verallgemeinerte Stromquellen dar.
 *$v, \omega$immer bezogen auf Inertialsystem. Jede Spannungsvariable e(t) entspricht im verallgemeinerten Netzwerk einem Konten. Das Massenpotential$e_0 = 0$ist dabei als Knoten mitzuzählen.
 * lange Hydraulikleitungen werden mit L modelliert.
 * Flussvariablen sind oft die Ableitungen von Erhaltungsgrößen: Ladung(Erhaltungsgröße) -> Strom(Flussvariable),  Impuls->Kraft, Drehimpuls->Drehmoment, Energie->Leistung, Masse->Massenstrom
 * Eine sehr große verallg. Induktivität wirkt als verallg. Stromquelle.
 * Bilanzgleichung der Erhaltungsgröße E:$\frac{dE}{dt} = m_{zu} - m_{ab}$
 * *Einheiten*: 
	* [R] =$\frac{[e]}{[f]} \underbrace{=}_{\text{elektrisch}} \frac{V}{A}=\Omega$
	* [C] =$[f]\frac{[t]}{[e]} \underbrace{=}_{\text{elektrisch}} \frac{A\cdot s}{V}=F \text{  Farad}$
	* [L] =$[e]\frac{[t]}{[f]} \underbrace{=}_{\text{elektrisch}} \frac{V\cdot s}{A}=H \text{  Henry}$

### Potentialspeicher:
$$
e(t) = \frac{1}{C} \int f(t) dt
$$

Potentialspeicher haben e(t) als Ausgang.

### Stromspeicher:
$$
f(t) = \frac{1}{L} \int e(t) dt
$$

### Generelle lineare Gesetze:
Leitet man den Potentialspeicher ab so folgt (1) und leitet man den Stromspeicher ab so folgt (3):

$$
\dot{e}=\frac{f}{C} \quad(1) \quad e = R\cdot f \quad (2) \quad \dot{f}=\frac{e}{L}\quad (3)
$$

für elekrisches System gilt also: (eingesetzt aus obiger Tabelle):
$$
\dot{U}=\frac{I}{C} \quad \text{"DUIC"} \quad U = R\cdot I \quad \text{"URI"} \quad U=L\cdot \dot{I}\quad \text{"ULDI"}
$$

Hierbei ist z.B. ULDI eine Merkhilfe für U=L (Dot) I. Hierbei beschreibt Gleichung (1) einen Potentialspeicher und Gleichung (3) einen Stromspeicher. 

Gleichung (4) beschreibt die Impulsgleichung und Gleichung (5) die Verschiebung (das ist keine Erhaltungsgröße). Das Integral der Flussgröße ist also der Impuls p(t) und das Integral der Potentialgröße die verallgemeinerte Verschiebung q(t).

$$
p(t) = C\cdot e(t) \quad (4) \quad q(t)=L\cdot f(t) \quad (5)
$$

wendet man Gleichung (4) für das elektrische System an folgt:

$$
 p(t) = C \cdot U \rightarrow Q=C\cdot U \quad (6) \text{ "QCU"  }
$$

leitet man Gleichung (4) ab folgt:

$$
\dot{p} = \dot{Q} = C \cdot \dot{U} = C \cdot \dot{e} \stackrel{\stackrel{C \dot{e}=f=I}{=}}{}I \rightarrow \dot{Q} = I \quad (7) 
$$

analog erhält man für Gleichung (4) für den translatorischen mechanischen Fall: 

$$
p(t) = m\cdot v(t) \quad \quad \dot{p} = F 
$$

Bei hydraulischen, pneumatischen oder thermischen Systemen ist oft ein nichtlinearer Zusammenhang gegeben. Dann wird bsp. Gleichung (4) und (5) wie folgt beschrieben:

$$
 e=h_e(p)  \quad \quad f = h_f(q) \quad \text{    bzw. aus (2) wird:     } \quad f=g(e)
$$

### Strom, Spannungsquelle offene Klemme oder Kurzschluss
| e| f|Element ist|
|---|---|---|
|e=0|f=beliebig| Kurzschluss|
|e=konst d.h.$\dot{e}=0$|beliebig|Spannunsgquelle|
|beliebig|f=0|offene Klemme|
|beliebig|f=konst d.h.$\dot{f}=0$|Stromquelle|

Ein Beispiel ist für die erste Zeile: In der Gleichung$e=f\cdot R$sieht man, dass
wenn e=0 d.h. wenn R gegen unendlich geht und f beliebig ist, dass dann die Spannung also e = 0 ist und
das bedeutet ein Kurzschluss. 

Ein anderes Beispiel: Gegeben ist eine Induktivität mit L=1/g und wobei nun g = 0 sein soll. Dann folgt$L=1/g \rightarrow \infty$und anhand der Gleichung$f(t) = 1/L\cdot \int e(t) dt$ist$I=0$. Die Induktivität wirkt also als Stromquelle. Sind nun die Anfangsbedingungen jedoch 0 so entspricht dies einer offenen Klemme.

### Verallgemeinerte Netzwerkanalyse

#### Systemordnung bestimmen
Allgemein gilt: 
 
 * bei ungefesselten **Teil**systemen kommt Ordnung 1 dazu wenn mit dem System auch aboslute Positionen berechnet werden sollen.
 * Die physikalische Systemordnung entspricht der Anzahl der vorhandenen Speicher (Kapazitäten, Induktivitäten)
 * Wenn 2 Speicher nur einen Freiheitsgrad besitzen so wird die Systemordnung um 1 reduziert. Die ist zum Beispiel der Fall bei einer Reihenschaltung von 2 Induktivitäten.
 * Die Systemordnung lässt sich auch anhand der Anzahl der Zustände also quasi das n der A Matrix ablesen (wenn A gegeben ist).
 * Teilsysteme die keine DGL enthalten, enthalten keine Speicher. 

#### Gyratoren
Gyratoren werden z.B. verwendet um mechanische Drehwelle über eine Pumpe in hydraulischen volumenstrom umzuwandeln?
Können aufgelöst werden indem auf der einen Seite des Gyrators folgendes angwandt wird:
	
 * Elemente in Reihe werden Prallel geschaltet
 * R -> 1/R, Kapazität wird zu Induktivität und umgekehrt
 * Stromquelle wird zur Spannungsquelle und umgekehrt. 

k=f_A/e_e


#### Transformatoren

k=f_a/f_e

### Mehrpol - Darstellung

ist eine günstige Darstellungsform zum Aufstellen von Deskriptorsystemen. Hierbei ist zu beachten, dass
als Eingangsgrößen des Deskriptorsystems nur Größen gewählt werden können, durch die es nicht möglich ist (auch nicht durch Kopplungsbedingungen)
Zustände zu bestimmen. Das heißt Eingangsgrößen dürfen nicht proportional zu Zustandsgrößen sein. Ein Zustand ist oft z.B. an jeder Induktivität und Kapazität.

## Modellvereinfachung

### Transformation SED -> ZRD
Dieses Kapitel beschreibt ein mögliches Vorgehen der Transformation der Semi-expliziten Deskriptor(SED) Darstellung in die Zustandsraum Darstellung (ZRD).

### Ortsdiskretisierung

### Ordnungsreduktion (Litz)

Mit dem Verfahren von Litz kann die Systemordnung auf wesentliche Zustände reduziert werden. Dabei ist zu beachten, dass mit den Dominanzmaßen Sk und Mk nur stationäre Endwerte der Übertragungspfade bewertet.

Dominante Eigenwerte:

 * Eigenwerte die betagsmäßig am nähsten am Ursprung liegen
 * Instabile beobacht- und steuerbare Eigenwerte sind immer dominant
 * Eigenwerte die hohe Einträge für das Summenmaß S und das Maximumsmaß M haben 
   verglichen mit den anderen Eigenwerten.

Für Sk und Mk gilt:

 * Mk fast gleich Sk: Ew großen Einfluss auf nur einen Übertragungsfpad 
 * Mk << Sk: Ew großen Einfluss auf mehrere Übertragungspfade

$q_{ikj}$ist die stationäre Verstärkung des Übertragungspfades j->i (Ausgang) für k-ten EW.
-->

## Numerisches Lösen von DGL's

### Übersichtstabelle Einschrittverfahren
|Verfahren|Vorschrift|p|K?|B-T|R(z)|Sta.|S(z)|
|---|---|---|---|---|---|---|---|
|Euler_e|$y_{n+1} = y_{n} + h \cdot f (t_n, y_n)$|1|ja|$\begin{array}{cc} {1} & {0} \\  \hline & {1} \end{array}$|$z-1$|0|---|
|Euler_i|$y_{n+1} = y_{n} + h \cdot f (t_{n+1}, y_{n+1})$|1|ja|$\begin{array}{cc} {1} & {1} \\  \hline & {1} \end{array}$|$\frac{1}{1-z}$|0,A,L|---|
|Heun2_e|$y_{n+1} = y_{n} + \frac{1}{2} (k_1+k_2)$<br>$k_1 =f(t_n,y_n)$<br>$k_2=f(t_n+h,y_n+k_1)$|2|ja|$\begin{array}{cc} {0} \\ 1 & {1} \\  \hline & {1/2} & 1/2 \end{array}$|$\frac{1}{1-z}$|0|---|
|Trapez_i|$y_{n+1} = y_{n} + \frac{1}{2} (k_1+k_2)$<br>$k_1 =f(t_n,y_n)$<br>$k_2=f(t_n+h,y_n+1/2 k_1+1/2 k_2)$|2|ja|$\begin{array}{ccc} {0} \\ 1 & {1/2} & 1/2 \\  \hline & {1/2} & 1/2 \end{array}$|$\frac{1}{1-z}$|0,A|-dd--|
|Mittelp._i|$y_{n+1} = y_{n} + f(t_n+\frac{1}{2}h, \frac{1}{2} y_{n+1})$|2|ja|$\begin{array}{cc} {1/2} & 1/2 \\ \hline & 1\end{array}$|$\frac{1}{1-z}$|0|![im-pic](im.png)|
|RK2_e|$y_{n+1} = y_{n} +(k_2)$<br>$k_1 =f(t_n,y_n)$<br>$k_2=f(t_n+\frac{1}{2}h, y_n+\frac{1}{2}k_1)$|2|ja|$\begin{array}{cc} {0} \\ 1/2 & 1/2  \\  \hline & {0} & 1 \end{array}$|$\frac{1}{1-z}$|0|---|
|Simpson_e<br>=RK3_e|für explizite-RK gilt allgemein: <br> $\Phi=\sum_{j=1}^{s} b_j k_j, \quad k_1=f(t,y)$ <br> $k_j=f(t+c_j h, y+h\sum_{l=1}^{j=1}a_{jk}k_l$<br>s: Stufenzahl, j=2...s,   $y_{n+1}=y_n+h\Phi$|3|ja|$\begin{array}{ccc} {0} \\ 1/2 & {1/2} \\1&-1&2 \\  \hline & {1/6} & 4/6 & 1/6 \end{array}$|$\frac{1}{1-z}$|0|---|
|Heun3_e|allgemeine Konsistenz Ordnungsregeln: <br> Voraussetzung: $\sum a_{ij} = c_i$ inv. gegen Autonomisierung <br> p=1: $\sum b_i = 1$  p=2: $\sum b_i c_i = \frac{1}{2}$<br>p=3: $\sum b_i c_i^2=\frac{1}{2}, \quad \sum b_i a_{ij} c_j = \frac{1}{6}$|3|ja|$\begin{array}{ccc} {0} \\ 1/3 & {1/3} \\2/3&0&2/3 \\  \hline & {1/4} & 2/4 & 1/4 \end{array}$|$\frac{1}{1-z}$|0|---|
|RK4_e| $y_{n+1} = y_{n} + \frac{1}{6} \cdot (k_1+2k_2+2k_3+k_4)$  <br> $k_1 =f(t_n,y_n)$ <br> $k_2=f(t_n+\frac{h}{2},y_n+\frac{h}{2}\cdot k_1)$<br> $k_3=(t_n+\frac{h}{2},y_n+\frac{h}{2}\cdot k_2)$ <br> $k_4=f(t_n+h,y_n+h \cdot k_3)$|4|ja|$\begin{array}{ccccc} 0\\ \frac{1}{2} & \frac{1}{2}\\\frac{1}{2} &0 &\frac{1}{2} \\1& 0& 0& 1\\\hline & \frac{1}{6} &\frac{1}{3} &\frac{1}{3} &\frac{1}{6} \end{array}$|$\frac{1}{1-z}$|0|---|
|RKM_e[^RKM]|mit p=4 bzw. 5|

Dabei ist:
 
 * Euler_e --> Explizites Euler Verfahren (i=implizit)
 * h die Schrittweite,
 * R(z) die Stabilitätsfunktion mit $z=\lambda \cdot h$:

$$
\begin{align}
R(z) = \frac{det(\mathbf{I}-z\cdot \mathbf{A}+z\cdot \begin{bmatrix}1\\\vdots\\1\end{bmatrix} \cdot \mathbf{b})}{det(\mathbf{I}-z\cdot \mathbf{A})}
\end{align}
$$
 
 * S(z) das Stabilitätsgebiet (dargestellt in weiß), 
 * p=Konsistenzordnung,
 * K?: Konvergent? --> für Einschrittverfahren(ESV) gilt Konsistenzordnung = Konvergenzordnung, Konsistenz+0-Stabilität=Konvergenz
 * B-T: Butcher Tabelau mit:$\begin{array}{c|c} \mathbf{c} & \mathbf{A} \\  \hline & \mathbf{b} \end{array}$
 * Sta. = Stabilität z.B. 0-(Dahlquist-stabil), $\alpha$ Winkelgebiet in linker Ebene (kein ESV ist $\alpha$ stabil), A-Stabil(komplette linke Ebene), L(Limes Stabil) --> wenn A-stabil und $\lim\limits_{Re(z) \rightarrow -\infty}{R(z)} = 0$

Für obige Tabelle können die Butcher Tableaus hier[^bt_wiki] überprüft werden.

Daneben gibt es noch weitere Verfahrens Konstruktions-Möglichkeiten: 

 * adjungierte Verfahren z.B. erst anwenden des Impliziten Euler(IE) Verfahrens und anschließend das Explizite Euler(EE) Verfahren hierdurch entsteht die Mittelpunktsregel bzw. die implizite Trapezregel wenn man erst das IE und dann das EE Verfahren anwendet. Hieraus entstehen dann oft selbstadjungierte Verfahren, die die günstige Eigenschaft haben, dass man pro Schritt 2 Ordnungen gewinnt? (TODO: passt das so?)
 * Extrapolation: Gehe erst einen Schritt mit Schrittweite h und anschließend mit Schrittweite h/2 des gleichen Verfahrens und extrapoliere anschließend: So erhält man eingebettete Verfahren.

### Übersichtstabelle Mehrschrittverfahren
|Verfahren|Vorschrift|p|K?|B-T|R(z)|Sta.|S(z)|
|---|---|---|---|---|---|---|---|
|BDF1_i|---|---|---|---|---|---|---|
|BDF2_i|---|---|---|---|---|---|---|
|PEC_e|---|---|---|---|---|---|---|
|MPEC_e|---|---|---|---|---|---|---|

Dabei ist: 

 * BDFp = Backward Formulation Difference
 * PEC=Predictor Evaluation Correction
 * MPEC:= Modifiziertes PEC

### Schrittweitenwahl
Möchte man ein System von ODE's (also eine ZRD) mittels eines ESV oder MSV simulieren, so muss man die Schrittweite so wählen,
dass man immer im Stabilitätsgebiet ist. Hierbei muss Eigenwert*h innerhalb von S liegen. 

## Simulation von linearen Systemen

Möchte man für ein lineares Zustandsraum-System der Form:

$$
\begin{align}
\dot{\mathbf{x}}(t) = \mathbf{A} \mathbf{x}(t)  + \mathbf{B}  \mathbf{u}(t)  \quad \quad \mathbf{x}(t_0)=\mathbf{x}_0
\end{align}
$$

die einzelnen Zustandsgrößen $\mathbf{x}(t)$ zu jedem Zeitpunkt berechnen, so gibt es grundsätzlich zwei Möglichkeiten:

 * Das Aufteilen der DGL in eine homogene und partikuläre Lösung [siehe hier](#aufteilen-in-homogene-und-partikulare-losung)
 * Das einbinden der Stellgröße u in eine homogene DGL der Form${\dot{\tilde{\mathbf{x}}}} = \mathbf{\tilde{A}} \mathbf{\tilde{x}}$und das anschließende Lösen dieser homogenen DGL (dieses Verfahren nennt man [Eingangsgrößen-Modellierung](#eingangsgroen-modellierung)).

Zu beachten ist hierbei, dass beide Verfahren exakte Lösungen berechnen. Möchte man hingegen nichtlineare DGL-Systeme analysieren ist die exakte Lösung in der Regel nicht bekannt und man ist auf numerische Näherungsverfahren wie zum Beispiel den Runge-Kutter-Verfahren angewiesen. 

### Aufteilen in homogene und partikuläre Lösung
Die geschlossene Lösungsformel lässt sich mittels der Transitionsmatrix$\mathbf{\Phi}(t) = e^{\mathbf{A}t}$berechnen: 

$$\mathbf{x}(t)= \mathbf{\Phi}(t-t_0) \mathbf{x}(t_0)+\int_{t_0}^t \mathbf{\Phi}(t-\tau) \mathbf{B} \mathbf{u}(\tau) d\tau$$

Diskretisiert man nun die obige Gleichung mit:

 *$t_0 = t_k$
 *$t = t_{k+1}$
 *$t-t_0 = T$

Annahme$\mathbf{u}(t)$ist eine Treppenfkuntion auf$[t_k, t_{k+1})$mit konstantem Wert$\mathbf{u}_k$

$$
\mathbf{x}(t_{k+1})= \mathbf{\Phi}(T) \mathbf{x}(t_k)+0
$$

Nun folgt mit der Substitution$t_{k+1} - \tau = v$: 

$$
\mathbf{x}(t_{k+1})= \mathbf{\Phi}(T) \mathbf{x}(t_k)+\int_{0}^T \mathbf{\Phi}(v) \mathbf{B} dv \cdot \mathbf{u}_k 
$$

Mit:
 
 * homogener Lösung:$\mathbf{\Phi}(T) \mathbf{x}(t_k)$
 * partikulärer Lösung:$\int_{0}^T \mathbf{\Phi}(v) \mathbf{B} dv \cdot \mathbf{u}_k$
 * und der Koeffizientenmatrix:$\mathbf{H}(t) = \int_{0}^T \mathbf{\Phi}(v) \mathbf{B} dv$

Zu beachten ist hierbei, dass nur wenn$\mathbf{u}(t)$eine Treppenfkuntion ist, die Zustände mit obiger Formel exakt berechnet werden können. Hierfür ist die zunächst die Berechnung der [Transitionsmatrix](Berechnen-der-Transitionsmatirx) und anschließend die Berechnung der [Koeffizientenmatrix](Berechnen-der-Koeffizientenmatrix) nötig.

Diese Herleitung wurde [[0]](#literatur) S.104 entnommen.

#### Berechnen der Transitionsmatrix
Es gibt mehrere Möglichkeiten die Transitionsmatrix zu berechnen:

 * A liegt in Diagonalform vor:$e^{A*t}= \begin{bmatrix}
e^{a_{11}t} &0 \\
0&e^{a_{22}t}\\
\end{bmatrix}$
 * A nicht diagonal aber alle EW von A einfach:$\Phi (t)=Te^{T^{-1}AT}T^{-1}, \quad T=[ev1, ev2, ...]$
 * Wenn A mehrfache EW enthält unterscheide ob komplex oder doppelt und wende Satz von Leonard an.
 * direkt mittels der inversen Laplace Transformation
 * über den Reihenentwicklungsansatz 
 * mit dem Verfahren von Plant (numerisch)
 * mit dem modifizierten Verfahren von Plant (numerisch)

#### Berechnen der Koeffizientenmatrix
TODO

### Eingangsgrößen Modellierung
TODO

## Literatur
 * [0] Prof. Dr.-Ing U. Konigorski: Modellbildung und Simulation - Skrtiptum der TU - Darmstadt 
 * [1] Antoulas Athanasios C.: Approximation of Large-Scale Dynamical Systems. Philadelphia: siam, 2005.
 * [2] Föllinger, O.: Regelungstechnik: Einführung in die Methoden und ihre Anwendung. 11. Auflage, Berlien, Offenbach: VDE Verlag 2013.
 * [0] [http://me-lrt.de/v1-6-mehrschrittverfahren](http://me-lrt.de/v1-6-mehrschrittverfahren)

## Fußnoten
[^mod_skript]: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
[^bt_wiki]: check here for BT: https://de.wikipedia.org/wiki/Runge-Kutta-Verfahren
[^RKM]: Das Runge-Kutta-Merson(KRM_e) Verfahren ist dabei ein Verfahren das zur Schrittweitensteuerung eingesetzt wird. Mehr dazu gibt es hier: https://www.encyclopediaofmath.org/index.php/Kutta-Merson_method


<!--
## Tests
???+ note "Phasellus posuere in sem ut cursus"
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod
    nulla. Curabitur feugiat, tortor non consequat finibus, justo purus auctor
    massa, nec semper lorem quam in massa.


??? note "question"
    Here's some content.

???+ abstract
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod
    nulla. Curabitur feugiat, tortor non consequat finibus, justo purus auctor
    massa, nec semper lorem quam in massa.

???+ question
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod
    nulla. Curabitur feugiat, tortor non consequat finibus, justo purus auctor
    massa, nec semper lorem quam in massa.

???+ example
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod
    nulla. Curabitur feugiat, tortor non consequat finibus, justo purus auctor
    massa, nec semper lorem quam in massa.

Lorem ipsum[^mod_skript] dolor sit amet, consectetur adipiscing elit.[^2]
-->

<!--- comments like this
ddd
 --->


