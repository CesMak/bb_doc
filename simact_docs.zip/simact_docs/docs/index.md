# Willkommen bei Simact

Simulative Adaptive Control Theory (Simact) ist eine Website, die folgendes bietet:

 * Zusammenfassung der Grundlagen der [Regelunstechnik](/theorie/index.html) ([klassisch](theorie/1_classical/1_classical/index.html), [linear](theorie/2_linear/2_linear/index.html), [nicht-linear](theorie/3_non_linear/3_non_linear/index.html), [k-I](theorie/4_ai/4_ai/index.html))
 * Simulatives Testen und Berechnen von komplexen Aufgaben der Regelungstechnik ([Engine](http://simact.de/engine/Engine/engine.html), [Beispiele](http://simact.de/engine/Engine/engine_help.html), [Funktionen](http://simact.de/engine/doc/global.html) )

Bei dem Projekt Simact können Sie selbst gerne mitmachen :). Sei es durch das schreiben einer kleinen Zusammenfassung oder durch das Programmieren eines regelungstechnischen Algorithmus. Wenn Sie Interesse haben oder Fehler auf dieser Seite entdecken kontaktieren Sie mich gerne unter:

MarkusLamprecht@live.de 

Wenn Sie mehr erfahren wollen schauen Sie gerne hier vorbei:

 * [Theorie](/theorie/1_classical/1_classical/index.html)
 * [Engine](/engine/index.html) 
 * [Kontakt](/kontakt/index.html)

Für die Forschungsinteressierten empfehle ich folgende Journals:

 * IEEE Transactions on Automatic Control 

Für die Praxis orientierten gibt's folgende Programme:

 * Modellica (Modellierung und Analyse hiermit möglich!)
 * Matlab
 * Octave (offline) ([online](https://octave-online.net/))
 * [SIMACT](http://simact.de/engine/Engine/engine.html) online tool
 * Wolfram Alpha

<!--- ## MkDocs>
This website is based on MkDocs which works like this:
For full documentation visit [mkdocs.org](http://mkdocs.org).

* `mkdocs new [dir-name]` - Create a new project.
* `mkdocs serve` - Start the live-reloading docs server.
* `mkdocs build` - Build the documentation site.
* `mkdocs help` - Print this help message.

## Holla

### subheading
#### subsubheading!

$$
\frac{n!}{k!(n-k)!} = \binom{n}{k}  \quad (1)
$$

$why is this not inline?!$

hallo \(x=3\)

Lorem ipsum dolor sit amet: $p(x|y) = \frac{p(y|x)p(x)}{p(y)}$
$y=2$

$$display$$ -->
