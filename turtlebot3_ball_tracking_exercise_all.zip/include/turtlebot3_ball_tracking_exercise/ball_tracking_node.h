// Multiple Kalman Filter by Markus Lamprecht
//Code reference: https://github.com/Myzhar/simple-opencv-kalman-tracker/blob/master/source/opencv-kalman.cpp

//Theory:
// state x: pos x[m] pos y[m]vel vx​[m/sec_]vel vy​[m/sec_]width [m]height [m]​

#ifndef TURTLEBOT3_BALL_TRACKING_NODE_H__
#define TURTLEBOT3_BALL_TRACKING_NODE_H__

#include <turtlebot3_ball_tracking_exercise/detector.h>

//Use image_transport for publishing and subscribing to images in ROS
#include <image_transport/image_transport.h>
//Use cv_bridge to convert between ROS and OpenCV Image formats
#include <cv_bridge/cv_bridge.h>
//Include some useful constants for image encoding.
//Refer to: http://www.ros.org/doc/api/sensor_msgs/html/namespacesensor__msgs_1_1image__encodings.html for more info.
#include <sensor_msgs/image_encodings.h>

#include <actionlib/server/simple_action_server.h>
#include <tf/transform_listener.h>

//Own Messages:
#include <turtlebot3_exercise_msgs/BallState.h>
#include <turtlebot3_exercise_msgs/AllBallStates.h>

// messagege stored in: devel/include/turtlebot3_exercise_msgs$
#include <turtlebot3_exercise_msgs/BallRequestAction.h>
#include <turtlebot3_exercise_msgs/BallRequest.h>
#include <turtlebot3_exercise_msgs/BallResult.h>

//Ros Messages:
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseArray.h>
#include <sensor_msgs/CameraInfo.h>


namespace turtlebot3
{

class BallTrackingNode
{

public:
  typedef actionlib::SimpleActionServer<turtlebot3_exercise_msgs::BallRequestAction> BallRequestActionServer;

  // constructor:
  BallTrackingNode(ros::NodeHandle& nh);
  //virtual ~BallTrackingNode();

  void update();

protected:
  void predictBallsPositions(cv::Mat &mat_input_img);

  void publishBallState(std::vector<Ball> balls);

  // UI callbacks
  void imageCallback(const sensor_msgs::ImageConstPtr& original_image);

  // Ball Tracking callbacks
  void btResultCb(const turtlebot3_exercise_msgs::BallResultConstPtr result);

  // ROS API callbacks
  void BallTrackingRequestActionGoalCb();

  // Action server help functions:
  // TODO testing function should be deleted in the end.
  void convertCameraPointToWorldFrame(geometry_msgs::PointStamped& cam_point);

  std::vector<Ball> getNearestBalls(const geometry_msgs::Point& point,const std_msgs::Header& header,int k);

  double getDistanceOfBall(geometry_msgs::Point reference_point_frame_link, double x_point, double y_point);

  // Draw debug image - methods:
  cv::Mat drawBallInCoordinateField(cv::Mat &input_mat, double ball_angle_in_rad, double ball_distance_in_m, int ball_label);

  cv::Mat drawResultPics(cv::Mat &input_img, std::vector<Ball> balls);

  // class members
  Detector detector_;

  // parameters
  tf::TransformListener tf_listener_;
  cv_bridge::CvImagePtr cv_ptr_;

  cv::Mat input_img_;
  bool init_once_;
  int frame_count_;
  double ticks_;
  time_t time_start_;
  time_t time_end_;
  float sec_;
  float fps_;

  // Constants from the parameter server:
  bool show_debug_img_;
  bool write_debug_img_;
  std::string absolute_img_path_;
  std::vector<double> camera_constants_;
  float specific_aging_;
  std::string world_frame_;
  std::string base_frame_;

  //publisher:
  ros::Publisher ball_state_pub_;
  ros::Publisher all_ball_states_pub_;

  // subscriber
  image_transport::Subscriber img_sub_;

  // action server
  boost::shared_ptr<BallRequestActionServer> ball_request_as_;
};
}

#endif
