#ifndef BALL_H__
#define BALL_H__

//Opencv includes:
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/video/video.hpp> //for kalman filter
#include <opencv2/highgui/highgui.hpp>

// ROS includes:
#include <ros/ros.h>

//CPP includes:
#include <sstream>
#include <iostream>
#include <time.h>
#include <cmath>

namespace turtlebot3
{

// macro to convert a string to a double
#define SSTR(x) static_cast<std::ostringstream&>(\
  (std::ostringstream() << std::dec << x)) \
  .str()

//macro to round a value to 2 digits
#define ROUND2(x) std::round(x * 100) / 100

class Ball
{
public:

  //Constructors:
  /**
   * @brief Creates a new Ball.
   * @param ball_px x,y=center of ball in px  z: radius of the ball in pixels.
   */
  Ball(cv::Point3d ball_px, std::vector<double> camera_constants, double specific_aging);

  Ball();

  // Kalman Filter:
  /**
   * @brief Initialize the Kalman Filter.
   */
  void initKalman();

  /**
   * @brief Updates the Measurement state[x,y,vx,vy] vector with new measurement values
   * @param old_ball_position new Point[x,y] in meter of the detected Ball
   * @param new_ball_position old Point[x,y] in meter of the ball which was detected before
   * @param dT time beteween two frames in sec.
   */
  void initMeas(cv::Point2f old_ball_position, cv::Point2f new_ball_position, float dT);

  /**
   * @brief Initialize the states vector with the measurement vector.
   */
  void initStates();

  /**
   * @brief Initialize Error Covarianze Matrix P
   */
  void initErrorCov();

  /**
   * @brief Correction Step of the Kalman Filter.
   */
  void kfCorrectionStep();

  /**
   * @brief Time Update Step of the Kalman Filter.
   * @param dT time beteween two frames in sec.
   */
  void kfTimeUpdateStep(float dT);

  // Ball Initialization methods:
  /**
   * @brief Initialize Error Circle.
   */
  void initErrorCircle();

  /**
   * @brief Initialize a ball's object (set all its attribute values to null).
   */
  void initBall();

  /**
   * @brief Initialize just the bool values (isnew, ismatched, ismatched) of a ball's object.
   */
  void initBallVisibility();

  /**
   * @brief Uses the detected rect (green bounding rect) to calculate and initialize
   * the position of the detected_ball_
   * @param rect_in_pixels A detected_rect in pixels domain.
   */
  void initDetectedPointInRelCoord(cv::Rect detected_rect);

  void initDetectedBallInRelCoord(cv::Point3d ball_px);

  // Pixel domain -> camera_link methods
  cv::Point2f pxToCameraLinkCoord(cv::Point3d ball_px);

  /**
   * @brief getDistance Calculates the distance (in x3 direction) between the camera_link and the ball.
   * @param balldiameter The diameter of the ball measured on the image in pixel.
   * @return the distance between the camera_link and the ball (this is not the diagonal distance!)
   */
  double getDistance(double balldiameter);

  /**
   * @brief getRay Converts a ball in pixel domain relative coordinates with respect to the camera_link.
   * @param ball_middle_point_x The x-origin point of the ball in pixel.
   * @param ball_middle_point_y The y-origin point of the ball in pixel.
   * @param distance The distance between the ball and the camera_link.
   * @return A Point3d with x: the ball is left/right to the camera_link by this value
   *                   with y: the ball is up/down to the camera_link by this value
   *                   with z: the distance between the camera_link and the ball.
   */
  cv::Point3d getRay(double ball_middle_point_x, double ball_middle_point_y, double distance);

  //Print methods:
  /**
   * @brief Print specific ball's attributes. Like its label and its position.
   * @return a string with specific attributes of the ball
   */
  std::string printBall();

  /**
   * @brief print the state vector[x,y,vx,vy] of the ball.
   * @return a string containing the state vector and the label of the ball.
   */
  std::string printState();

  //get/set methods:
  void setIsMatched(bool is_matched_) { this->is_matched_ = is_matched_; }
  bool getIsMatched() { return this->is_matched_; }

  void setIsUnmatched(bool is_unmatched_) { this->is_unmatched_ = is_unmatched_; }
  bool getIsUnmatched() { return this->is_unmatched_; }

  void setIsNew(bool is_new_) { this->is_new_ = is_new_; }
  bool getIsNew() { return this->is_new_; }

  void setIsDetected(bool is_detected_) { this->is_detected_ = is_detected_; }
  bool getIsDetected() { return this->is_detected_; }

  void setNotFoundCount(int not_found_count_) { this->not_found_count_ = not_found_count_; }
  int getNotFoundCount() { return this->not_found_count_; }

  void setMatchedCount(int matched_count_) { this->matched_count_ = matched_count_; }
  int getMatchedCount() { return this->matched_count_; }

  void setLabel(int label_) { this->label_ = label_; }
  int getLabel() { return this->label_; }

  void setPredictedBall( cv::Point2f  predicted_ball_) { this->predicted_ball_ = predicted_ball_; }
  cv::Point2f  getPredictedBall() { return this->predicted_ball_; }
  void setErrorEllipse(cv::RotatedRect error_ellipse_) { this->error_ellipse_ = error_ellipse_; }
  cv::RotatedRect getErrorEllipse() { return this->error_ellipse_; }
  void setDetectedBall(cv::Point2f detected_ball_) { this->detected_ball_ = detected_ball_; }
  cv::Point2f getDetectedBall() { return this->detected_ball_; }

  cv::Mat getState(){return this->state_; }

  std::vector<double> getCameraConstants(){return this->cc_;}
  double getSpecificAging(){return this->specific_aging_;}

  void setSpecificAging(float specific_aging) { this->specific_aging_ = specific_aging; }

  cv::Point3d getDetectedBallPx(){return this->detected_ball_px_;}
protected:

  //Ball parameters:
  int not_found_count_; //Counts how often the ball was NOT detected
  int matched_count_; //Counts how often the ball was detected
  int label_; // a label of the ball. (e.g. a number)
  bool is_detected_; // true if a ball was detected once.
  bool is_matched_;  // true if a ball was found before and could be assigned.
  bool is_unmatched_; // true if a ball was found before but is currently occluded and could not be assigned.
  bool is_new_; // true if a ball was first found.

  // Note: Just left/right displacement of the ball = x and the distance to the ball from the camera = y
  // is stored in the predicted_ball_ and also in the detected_rect
  // Additionally the up/down placement of the detected_rect is stored in the result_ray_.
  cv::Point2f predicted_ball_; // the position of the predicted (pink) ball in the camera_link frame.
  cv::RotatedRect error_ellipse_; // the error ellipse (red) ball in the camera_link frame.
  cv::Point2f detected_ball_; // the position of the found ball (green) in the camera_link frame.

  cv::Point3d detected_ball_px_;

  //Ball aging parameters e.g. when a ball is deleted
  double error_factor_;
  double specific_aging_;

  //Kalman Filter's params:
  cv::KalmanFilter kf_;
  cv::Mat state_;
  cv::Mat meas_;

  int stateSize_;
  int measSize_ ;

  // camera "constant" values and ball_diameter:
  std::vector<double> cc_;

  cv::Point3d result_ray_; // stores 3d detected ball position (x3 distance to ball, x2, height above ground)
  cv::Point3d debug_params_; // ball middlepoint x, y and diameter of bal in px.

};
} //end namespace turtlebot3
#endif // BALL_H__
