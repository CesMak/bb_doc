#ifndef FRAME_H__
#define FRAME_H__

#include <turtlebot3_ball_tracking_exercise/ball.h>

namespace turtlebot3
{

class Detector
{
public:

  //Constructor:
  Detector();

  // Ball Detection:
  /**
   * @brief Use the input_image and use a color thresholding method to extract the orange balls.
   * @param input_mat The picture_matrix of the input image.
   */
  void getBallsDetectionImg(cv::Mat &input_mat);

  /**
   * @brief Use the black_white picture, detect the balls'contours and thereby
   * the bounding rect around this circle
   * @param camera_constants The camera_constants just have to be passed as they are required to initialize a ball's object
   * @param specific_aging  This parameter also has to be passed as it is required to initialize a ball's object
   * @return
   */
  std::vector<Ball> findballs(std::vector<double> camera_constants, double specific_aging);

  /**
   * @brief The camera's RGB input image is used to detect balls which
   * have a certain color range (defined in HSV Range's).
   * @param mat_input_img The camera's RGB input image.
   * @param dT The time between two images.
   * @param camera_constants The calibration constants of the camera.
   */
  void detectBalls(cv::Mat &mat_input_img, float dT, std::vector<double> camera_constants,double specific_aging);

  // Kalman Filter:
  /**
   * @brief In the prediction step the time of all detected balls is updated.
   */
  void predictionStep();

  /**
   * @brief In the correction Step the balls are first assigned (new,matched,unmatched(occluded))
   * and then the correction step is exectued for all matched balls. New balls are initialized.
   * @param detected_balls A list of the balls.
   */
  void correctionStep(std::vector<Ball> detected_balls);

  // helper functions:
  bool pointInEllipse(float x, float y, float xp, float yp, float d, float D, float angle);
  int  checkBallInErrorEllipse(std::vector<Ball> detected_balls, Ball b);

  //get and set functions:
  void setBlackWhite(cv::Mat &black_white_) { this->black_white_ = black_white_; }
  cv::Mat getBlackWhite() { return this->black_white_; }

  void setBalls(std::vector<Ball> balls_) { this->balls_ = balls_; }
  std::vector<Ball> getBalls() { return this->balls_; }

  int getImageNumber(){return img_number_;};

  void setHSVValues(int min_h_blue,int max_h_blue,int min_h_green, int max_h_green, int min_h_red, int max_h_red)
  {
    this->MAX_H_BLUE_=max_h_blue;
    this->MIN_H_BLUE_=min_h_blue;
    this->MIN_H_GREEN_=min_h_green;
    this->MAX_H_GREEN_=max_h_green;
    this->MAX_H_RED_=max_h_red;
    this->MIN_H_RED_=min_h_red;
  }

  void setDeleteRatio(float delete_ratio){this->delete_ratio_=delete_ratio;}

  // testing hough circles:
  //std::vector<cv::Vec3f> getHoughCircles(){return this->circles_;}
protected:

  //parameters:
  std::vector<Ball> balls_;
  int img_number_;
  float dt_; //sampling number
  cv::Mat black_white_; //the black white detection matrix of the balls!

  //testing hough circles:
  //std::vector<cv::Vec3f> circles_;

  // constants initialized by parameter server:
  int MIN_H_BLUE_;
  int MAX_H_BLUE_;
  int MIN_H_GREEN_;
  int MAX_H_GREEN_;
  int MIN_H_RED_;
  int MAX_H_RED_;

  float delete_ratio_;
};

}
#endif // FRAME_H
