#include <turtlebot3_ball_tracking_exercise/ball_tracking_node.h>

namespace turtlebot3
{

// constructor:
BallTrackingNode::BallTrackingNode(ros::NodeHandle& nh)
{
  //get params
  show_debug_img_=nh.param("ball_tracking/show_debug_img", true);
  write_debug_img_=nh.param("ball_tracking/write_debug_img", true);
  absolute_img_path_=nh.param("ball_tracking/img_path",std::string("../ros_space/tb3_ex/src/tuda_turtlebot3_exercises/turtlebot3_ball_tracking_exercise/img/"));
  detector_.setHSVValues(nh.param("ball_tracking/min_h_blue",0),
                       nh.param("ball_tracking/max_h_blue",25),
                       nh.param("ball_tracking/min_h_green",60),
                       nh.param("ball_tracking/max_h_green",255),
                       nh.param("ball_tracking/min_h_red",50),
                       nh.param("ball_tracking/max_h_red",255));

  detector_.setDeleteRatio(nh.param<double>("ball_tracking/delete_ratio", 1.6));
  specific_aging_= nh.param<double>("ball_tracking/specific_aging", 5.0);

  world_frame_ = nh.param("ball_tracking/world_frame", std::string("world"));
  base_frame_ = nh.param("ball_tracking/base_frame", std::string("camera_link"));

  //subscriber:
  image_transport::ImageTransport it(nh);
  // rectified image: turtlebot3/sensor/camera/rgb/image_rect_color
  // unrectified img: /turtlebot3/sensor/camera/rgb/image_color

  img_sub_ = it.subscribe("/turtlebot3/sensor/camera/rgb/image_rect_color", 1, &BallTrackingNode::imageCallback,this);

  // subscribe only once:
  sensor_msgs::CameraInfoConstPtr msg = ros::topic::waitForMessage<sensor_msgs::CameraInfo>(std::string("/turtlebot3/sensor/camera/rgb/camera_info"));
  camera_constants_=std::vector<double>(7);
  camera_constants_.at(0)=300.9836819547345;//msg->P.at(2); //cx
  camera_constants_.at(1)=248.23578928969619;//msg->P.at(6); //cy
  camera_constants_.at(2)=602.62353515625;//msg->P.at(0); //fx
  camera_constants_.at(3)=615.0336303710938;//msg->P.at(5); //fy
  camera_constants_.at(4)=0.0;//msg->P.at(3); //Tx
  camera_constants_.at(5)=0.0;//msg->P.at(7); //Ty
  camera_constants_.at(6)=nh.param("ball_tracking/ball_diameter",0.064);

  //publisher:
  ball_state_pub_ = nh.advertise<turtlebot3_exercise_msgs::BallState>("ball_state", 1);
  all_ball_states_pub_=nh.advertise<turtlebot3_exercise_msgs::AllBallStates>("all_ball_states", 1);

  // init action servers
  ball_request_as_.reset(new BallRequestActionServer(nh, "ball_request", false));
    //  registerGoalCallback (boost::function< void()> cb)
    //  Allows users to register a callback to be invoked when a new goal is available.
  ball_request_as_->registerGoalCallback(boost::bind(&BallTrackingNode::BallTrackingRequestActionGoalCb, this));

  ball_request_as_->start();

  init_once_=true;
}

void BallTrackingNode::update()
{
  // publish ball state:
    publishBallState(detector_.getBalls());
}

void BallTrackingNode::predictBallsPositions(cv::Mat &mat_input_img)
{
  if (init_once_) { //just once
    frame_count_ = 0;
    ticks_ = 0;
    time(&time_start_); //time_start_ the clock
    init_once_ = false;
  }

  // loop:
  double precTick = ticks_;
  ticks_ = (double)cv::getTickCount();
  double dT = (ticks_ - precTick) / cv::getTickFrequency();

  detector_.detectBalls(mat_input_img, dT, camera_constants_, specific_aging_);

  time(&time_end_);

  sec_ = difftime(time_end_, time_start_);
  fps_ = frame_count_ / sec_;
  ++frame_count_;
}


void BallTrackingNode::publishBallState(std::vector<Ball> balls)
{
  //TODO: this message should be published in the world coordinates!
  // That is not a big deal: just use the ray positions!
  // As fast as they are correct!
  turtlebot3_exercise_msgs::AllBallStates all_ball_states_msg;

  std::vector<turtlebot3_exercise_msgs::BallState>  ball_state_msg (balls.size());

    for(int i=0;i<balls.size();i++)
    {
      Ball ball = balls[i];
      ball_state_msg.at(i).x_pos=(double) ball.getPredictedBall().x;
      ball_state_msg.at(i).y_pos=(double) ball.getPredictedBall().y;
      ball_state_msg.at(i).x_vel=(double) ball.getState().at<float>(2);
      ball_state_msg.at(i).y_vel=(double) ball.getState().at<float>(3);
      ball_state_msg.at(i).ball_number=ball.getLabel();
      ball_state_msg.at(i).header.stamp = ros::Time::now();
      ball_state_msg.at(i).header.frame_id = "camera_link";
    }
    all_ball_states_msg.frame_number=frame_count_;
    all_ball_states_msg.balls=ball_state_msg;
    all_ball_states_pub_.publish(all_ball_states_msg);
}


void BallTrackingNode::imageCallback(const sensor_msgs::ImageConstPtr& original_image)
{
  //This function is called everytime a new image is subscribed

  //Convert from the ROS image message to  a CvImage suitable for working with OpenCV for processing
  try {
    //Always copy, returning a mutable CvImage
    //OpenCV expects color images to use BGR channel order.
    cv_ptr_ = cv_bridge::toCvCopy(original_image, sensor_msgs::image_encodings::BGR8);

    // copy pointer to mat:
    input_img_ = cv_ptr_->image;
  }
  catch (cv_bridge::Exception& e) {
    ROS_ERROR("cv_bridge exception: %s", e.what());
    return;
  }

  predictBallsPositions(input_img_);
  //predictBallsPositions(cv_ptr_);

  //Display the image for debugging using OpenCV
    if(show_debug_img_)
    {
      cv::Mat result_mat=drawResultPics(input_img_, detector_.getBalls());
      imshow("Ball Tracking Exercise:",result_mat);
      if(write_debug_img_)
        imwrite( absolute_img_path_+ SSTR(frame_count_) + ".png",result_mat );

      //Add some delay in milisec_onds. The function only works if there is at least one HighGUI window created and the window is active.
      //If there are several HighGUI windows, any of them can be active.
      cv::waitKey(3);
    }

    // TODO - some testing:
    // should be deleted in the end!
    geometry_msgs::PointStamped example_point;
    example_point.header.stamp = ros::Time::now();
    example_point.header.frame_id ="camera_link";
    example_point.point.x=0.1; //10cm
    example_point.point.y=0.5; // on the ground
    example_point.point.z=0.0; // distance to cam.
    convertCameraPointToWorldFrame(example_point);
}



// Methods for the action server:
std::vector<Ball> BallTrackingNode::getNearestBalls(const geometry_msgs::Point& point, const std_msgs::Header& header, int k)
{
  //TODO: Check again if this converts the input point into the camera_link coordinate frame:
  geometry_msgs::PointStamped input_stamped_point;
  input_stamped_point.point = point;
  input_stamped_point.header = header;

  geometry_msgs::PointStamped given_point;
    if( (header.frame_id != base_frame_))
    {
      try
      {
        if (tf_listener_.canTransform(base_frame_, header.frame_id, header.stamp))
        {
          tf_listener_.transformPoint(base_frame_, input_stamped_point, given_point);
        }
      }
      catch (tf::TransformException ex)
      {
        ROS_ERROR("%s", ex.what());
      }
    }
    else
    {
      given_point.point=point;
    }

    //get all distances between the input point and all balls in the camera_link frame_id
    std::vector<Ball> balls = detector_.getBalls();
    typedef std::pair<double,Ball> pairType;
    std::vector<pairType> ordered_balls_vec(balls.size());
    double x_pos,y_pos,dis=0;

    for (int j = 0; j < balls.size(); j++)
    {
      x_pos=(double) balls.at(j).getPredictedBall().x;
      y_pos=(double) balls.at(j).getPredictedBall().y;
      dis=getDistanceOfBall(given_point.point,x_pos,y_pos);
      ordered_balls_vec[j]= std::make_pair(dis,balls.at(j));
    }

    std::sort(std::begin(ordered_balls_vec), std::end(ordered_balls_vec), [](pairType& first,
              pairType& second)->bool { return first.first < second.first; });

    std::vector<Ball> k_nearest_balls (k);
    for (int p=0;(p<k)&&(p<balls.size());p++)
    {
      k_nearest_balls.at(p)=ordered_balls_vec.at(p).second;
    }

    return k_nearest_balls;
}

double BallTrackingNode::getDistanceOfBall(geometry_msgs::Point reference_point_frame_link, double x_point, double y_point)
{
    return sqrt((reference_point_frame_link.x-x_point)*(reference_point_frame_link.x-x_point)+(reference_point_frame_link.y-y_point)*(reference_point_frame_link.y-y_point));
}

// a method that converts the relative ball position point (x1,x2=height,x3=distance) into
// world coordinates.
// base_frame_ = camera_link
// world_frame_ = world
// TODO: can I just use ros::Time::now() ? instead of a specific time?
void BallTrackingNode::convertCameraPointToWorldFrame(geometry_msgs::PointStamped& cam_point)
{
//  //the point given relative to the camera_link coordinate system
  geometry_msgs::PointStamped result_point;
  world_frame_="base_link";
  try
  {
    if (tf_listener_.canTransform(world_frame_, base_frame_, ros::Time(0)))
     {
//      std::cout<<"can be transformed"<<std::endl;
      tf_listener_.transformPoint(world_frame_, cam_point, result_point);
     // transformPoint (const std::string &target_frame, const geometry_msgs::PointStamped &stamped_in, geometry_msgs::PointStamped &stamped_out) const
    }
  }
  catch (tf::TransformException ex)
  {
    ROS_ERROR("%s", ex.what());
  }

//    std::cout<<"input point: "<<base_frame_<<cam_point.point<<std::endl;
//    std::cout<<"output point: "<<world_frame_<<result_point.point<<std::endl;

//    // get transformation works:
//    tf::StampedTransform transform;
//    try{
//      tf_listener_.lookupTransform("/base_link", "/camera_link",
//                               ros::Time(0), transform);
//    }
//    catch (tf::TransformException ex){
//      ROS_ERROR("%s",ex.what());
//    }
//    std::cout<<transform.getOrigin().y()<<std::endl;
}


void BallTrackingNode::BallTrackingRequestActionGoalCb()
{
   //check if new goal was preempted in the meantime
  if (ball_request_as_->isPreemptRequested())
  {
    ball_request_as_->setPreempted();
    return;
  }

  // accept the new goal
  const turtlebot3_exercise_msgs::BallRequestGoalConstPtr goal = ball_request_as_->acceptNewGoal();

  // get k nearest balls and return them in camera_link coordinate system
  std::vector<Ball> k_nearest_balls = getNearestBalls(goal->request.position.point, goal->request.position.header, goal->request.number_nearest_balls);

  // transform balls in camera_link coordinate system to target_frame:
  geometry_msgs::PointStamped stamped_in;
  stamped_in.header.stamp=goal->request.position.header.stamp;
  stamped_in.header.frame_id=base_frame_;

  geometry_msgs::PointStamped stamped_out;

  std::vector<turtlebot3_exercise_msgs::BallState>  ball_state_msg (k_nearest_balls.size());

  for (int i=0;i<k_nearest_balls.size();i++)
  {
    geometry_msgs::Point ball_position;
    ball_position.x=k_nearest_balls.at(i).getPredictedBall().x;
    ball_position.y=k_nearest_balls.at(i).getPredictedBall().y;
    stamped_in.point =ball_position;
    try
    {
      if (tf_listener_.canTransform(goal->request.target_frame,base_frame_,stamped_in.header.stamp))
      {
        tf_listener_.transformPoint(goal->request.target_frame,stamped_in, stamped_out);
      }
    }
    catch (tf::TransformException ex)
    {
      ROS_ERROR("%s", ex.what());
      ros::Duration(1.0).sleep();
    }

    ball_state_msg.at(i).x_pos = stamped_out.point.x;
    ball_state_msg.at(i).y_pos = stamped_out.point.y;
    //TODO: velocity has also be transformed?
    ball_state_msg.at(i).header.stamp = stamped_out.header.stamp;
    ball_state_msg.at(i).header.frame_id = goal->request.target_frame;
  }

  turtlebot3_exercise_msgs::BallResult ball_result_msg;
  ball_result_msg.balls=ball_state_msg;

  //const turtlebot3_exercise_msgs::BallTrackingResultConstPtr

  if (ball_request_as_->isActive())
  {
    // send action result
    turtlebot3_exercise_msgs::BallRequestResult action_result;
    action_result.result = ball_result_msg;
    ball_request_as_->setSucceeded(action_result);
  }
}


// Draw debug image - methods:
cv::Mat BallTrackingNode::drawResultPics(cv::Mat &input_img, std::vector<Ball> balls)
{
  //right pic: relative coord.:
  cv::Mat result = cv::Mat::zeros(480, 960, CV_8UC3);

  cv::Mat mat23 = cv::Mat::zeros(480, 320, CV_8UC3);
  cv::Mat mat2 = detector_.getBlackWhite();
  cv::cvtColor(mat2, mat2, CV_GRAY2RGB);
  cv::resize(mat2, mat2, cv::Size(320, 240));

  //mat2= left pic:!
  for (int p = 0; p < balls.size(); p++) {
    Ball b = balls[p];

    cv::Point2f center;
    center.x=b.getDetectedBallPx().x;
    center.y=b.getDetectedBallPx().y;

    if(!b.getIsUnmatched())
    {
      cv::circle(input_img, center, b.getDetectedBallPx().z, CV_RGB(0, 255, 0), 2);
    }
    else
    {
     cv::circle(input_img, center, b.getDetectedBallPx().z, CV_RGB(0, 100, 0), 2);
    }

  }

  //testing hough:
//  std::vector<cv::Vec3f> hough_circles;
//  hough_circles = detector_.getHoughCircles();
//  for(int j=0; j<hough_circles.size();j++)
//  {
//    cv::Point2f center((hough_circles[j][0]), (hough_circles[j][1]));
//    double radius = (hough_circles[j][2]);
//    cv::circle(input_img, center, radius, CV_RGB(255, 255, 0), 2);
//  }

  // mat3 is right top
  cv::Mat mat3 = cv::Mat::zeros(240, 320, CV_8UC3);

  //print ks: right pic=mat3:
  cv::line(mat3,cv::Point(0, 240), cv::Point(320, 240), cv::Scalar(255, 150, 255), 5);
  cv::line(mat3,cv::Point(160, 40), cv::Point(160, 240), cv::Scalar(255, 150, 255), 2);
  for (int i = 1; i <= 20; i++) {
    cv::putText(mat3, SSTR(i * 10), cv::Point(165, 240 - 10 * i), cv::FONT_HERSHEY_SIMPLEX, 0.2, CV_RGB(255, 150, 255), 0.8); // in cm y- Axis!
  }
  for (int i = 16; i > 0; i--) {
    cv::putText(mat3, SSTR(-i * 10), cv::Point(160 - i * 10, 234), cv::FONT_HERSHEY_SIMPLEX, 0.18, CV_RGB(255, 150, 255), 0.8); // in cm x- Axis!
    cv::putText(mat3, SSTR(i * 10), cv::Point(160 + i * 10, 234), cv::FONT_HERSHEY_SIMPLEX, 0.18, CV_RGB(255, 150, 255), 0.6); // in cm y- Axis!
  }

  for (int p = 0; p < balls.size(); p++) {
    Ball b = balls[p];

    cv::putText(mat2, b.printBall(), cv::Point(2, 10 + 13 * p), cv::FONT_HERSHEY_SIMPLEX, 0.3, CV_RGB(255, 255, 255), 1.0);

    //print state:
    cv::putText(mat2, b.printState(), cv::Point(100, 150 + 13 * p), cv::FONT_HERSHEY_SIMPLEX, 0.3, CV_RGB(255, 100, 255), 1.0);

    //green:
    if (!b.getIsUnmatched()) {
      cv::circle(mat3, cv::Point(160 + b.getDetectedBall().x * 100, 240 - b.getDetectedBall().y * 100), 3, CV_RGB(100, 255, 0), -1, 8, 0);
    }
    else {
      cv::circle(mat3, cv::Point(160 + b.getDetectedBall().x * 100, 240 - b.getDetectedBall().y * 100), 3, CV_RGB(0, 100, 0), -1, 8, 0); //dark green!
    }

    //pink:
    cv::circle(mat3, cv::Point(160 + b.getPredictedBall().x * 100, 240 - b.getPredictedBall().y * 100), 3, CV_RGB(255, 0, 255), 1, 8, 0);

    //red:
    cv::RotatedRect rRect = b.getErrorEllipse();
    rRect.center.x = rRect.center.x * 100 + 160;
    rRect.center.y = -rRect.center.y * 100 + 240;
    rRect.size.height = rRect.size.height * 100;
    rRect.size.width = rRect.size.width * 100;
    ellipse(mat3, rRect, CV_RGB(255, 0, 0), 1, 7);
    // linie zum punkt: cv::linemat3,Point(160,240),Point(160+x*2,240-y*2),cv::Scalar(0,255,255),

    //blue text:
    cv::putText(mat3, SSTR(b.getLabel()), cv::Point(162 + b.getPredictedBall().x * 100, 238 - b.getPredictedBall().y * 100), cv::FONT_HERSHEY_SIMPLEX, 0.3, CV_RGB(100, 150, 255), 1);
  }

  //draw Legend above:
  //draw legend below
  cv::putText(input_img, "detected ball", cv::Point(10, 15), cv::FONT_HERSHEY_SIMPLEX, 0.6, CV_RGB(0, 255, 0), 2);
  cv::putText(input_img, "last detected ball", cv::Point(150, 15), cv::FONT_HERSHEY_SIMPLEX, 0.5, CV_RGB(0, 100, 0), 2);
  cv::putText(input_img, "estimated ball", cv::Point(350, 15), cv::FONT_HERSHEY_SIMPLEX, 0.6, CV_RGB(255, 0, 255), 2);
  cv::putText(input_img, "error ball", cv::Point(500, 15), cv::FONT_HERSHEY_SIMPLEX, 0.6, CV_RGB(255, 0, 0), 2);

  cv::putText(input_img, "fps_ " + SSTR((int)fps_), cv::Point(10, 70), cv::FONT_HERSHEY_SIMPLEX, 0.75, CV_RGB(255, 255, 0), 2);
  cv::putText(input_img, "img " + SSTR(frame_count_), cv::Point(10, 90), cv::FONT_HERSHEY_SIMPLEX, 0.75, CV_RGB(255, 255, 0), 2);
  cv::putText(input_img, "time " + SSTR(sec_), cv::Point(10, 110), cv::FONT_HERSHEY_SIMPLEX, 0.75, CV_RGB(255, 255, 0), 2);


  vconcat(mat2, mat3, mat23);
  hconcat(input_img, mat23, result);

  return result;
}

//this method is not used
cv::Mat BallTrackingNode::drawBallInCoordinateField(cv::Mat &input_mat, double ball_angle_in_rad, double ball_distance_in_m, int ball_label)
{
  // res mat: 480x300
  int degphi = ball_angle_in_rad * 180 / 3.14159;
  int degphimitte = 90 - degphi;
  int y = sin(abs(ball_angle_in_rad)) * ball_distance_in_m;
  int x = cos(abs(ball_angle_in_rad)) * ball_distance_in_m;
  //  cout<<"x: "<<x<<"  y: "<<y<<" phimiddle: "<<degphimitte<<endl;
  cv::circle(input_mat, cv::Point(160 + x * 2, 240 - y * 2), 3, cv::Scalar(60, 150, 255), 2, 8, 0);
  line(input_mat, cv::Point(0, 240), cv::Point(320, 240), cv::Scalar(0, 255, 0), 5);
  line(input_mat, cv::Point(160, 0), cv::Point(160, 240), cv::Scalar(0, 255, 2), 2);
  line(input_mat, cv::Point(160, 240), cv::Point(160 + x * 2, 240 - y * 2), cv::Scalar(0, 255, 255), 0.9);
  cv::putText(input_mat, "B:" + SSTR(ball_label) + " dist:" + SSTR(ball_distance_in_m) + "cm" + " x: " + SSTR(x) + "cm", cv::Point(5, 30 + 15 * ball_label), cv::FONT_HERSHEY_SIMPLEX, 0.35, cv::Scalar(100, 0, 255), 1);
  cv::putText(input_mat, "B:" + SSTR(ball_label) + " phi : " + SSTR(degphimitte) + "gr y: " + SSTR(y) + "cm", cv::Point(5, 60 + 15 * ball_label), cv::FONT_HERSHEY_SIMPLEX, 0.35, cv::Scalar(100, 0, 255), 1);
  return input_mat;
}



} //end of tb3 namespace.


int main(int argc, char** argv)
{
  ros::init(argc, argv, "turtlebot3_ball_tracking");
  ROS_INFO("start ball_traking_exercise:");

//  std::string s = std::to_string(CV_MAJOR_VERSION);
//  std::cout << "OPEN CV VERSION: " << s << std::endl;

  ros::NodeHandle nh;

  turtlebot3::BallTrackingNode node(nh);
  ros::Rate loop_rate(nh.param("ball_tracking/update_rate", 1.0));

  while (ros::ok())
  {
    ros::spinOnce();
    node.update();
    loop_rate.sleep();
  }

  return 0;
}

