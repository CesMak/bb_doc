#include <turtlebot3_ball_tracking_exercise/detector.h>

namespace turtlebot3
{

// Constructor:
Detector::Detector()
{
}



// Ball Detection:
void Detector::getBallsDetectionImg(cv::Mat &mat)
{
  //>>>>> Noise smoothing
  // with the &mat reference the input image is changed!
   cv::GaussianBlur(mat, mat, cv::Size(5, 5), 3.0, 3.0);
  // <<<<< Noise smoothing

  // >>>>> HSV conversion
  cv::cvtColor(mat, mat, CV_BGR2HSV);
  // <<<<< HSV conversion

  // >>>>> Color Thresholding
  // Note: change parameters for different colors
  black_white_ = cv::Mat::zeros(mat.size(), CV_8UC1);
  cv::inRange(mat, cv::Scalar(MIN_H_BLUE_, MIN_H_GREEN_, MIN_H_RED_),
          cv::Scalar(MAX_H_BLUE_, MAX_H_GREEN_, MAX_H_RED_), black_white_);
  // <<<<< Color Thresholding

  // testing - houghcircles
  //cv::Mat test;
  //cv::cvtColor(mat, test, CV_BGR2GRAY);
  //cv::HoughCircles(test, circles_, CV_HOUGH_GRADIENT, 1 , 10, 100, 55, 20, 400 );
  //  cv::HoughCircles(test, circles_, CV_HOUGH_GRADIENT, 2 , 10, 100, 60, 20, 400 );

  // >>>>> Improving the result
  cv::erode(black_white_, black_white_, cv::Mat(), cv::Point(-1, -1), 2);
  cv::dilate(black_white_, black_white_, cv::Mat(), cv::Point(-1, -1), 2);
  // <<<<< Improving the result

}

std::vector<Ball> Detector::findballs(std::vector<double> camera_constants, double specific_aging)
{
  std::vector<Ball> detected_balls;

  // >>>>> Contours detection
  std::vector<std::vector<cv::Point> > contours;
  cv::findContours(black_white_, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
  // <<<<< Contours detection

  // min enclosing circle:
  std::vector<cv::Point2f> center( contours.size() );
  std::vector<float> radius( contours.size() );
  for (size_t i = 0; i < contours.size(); i++)
  {
    // TODO/alternative use: minEnclosingCircle
      minEnclosingCircle( contours[i], center[i], radius[i] );

      double fill_ratio = cv::contourArea(contours[i])/(radius[i]*radius[i]*3.14159);

      // let the minimum radius be 39px -> max. distance = 50.7cm
      // let the minimum radius be 25px -> max. distance = 79.2cm
      // let the minimum radius be 20px -> max. distance = 99cm
      if(radius[i]>20.0 && fill_ratio > 0.6)
      {
         cv::Point3d ball_px;
         ball_px.x=center[i].x;
         ball_px.y=center[i].y;
         ball_px.z=radius[i];

         Ball bb(ball_px, camera_constants, specific_aging);
         detected_balls.push_back(bb);
      }
  }

  return detected_balls;
}

void Detector::detectBalls(cv::Mat &mat_input_img,float dT, std::vector<double> camera_constants, double specific_aging)
{
  dt_=dT;

  predictionStep();

  //>>> Detect Balls:
  getBallsDetectionImg(mat_input_img);
  std::vector<Ball> detected_balls = findballs(camera_constants, specific_aging);
  //<<<<< Detect Balls

  correctionStep(detected_balls);
}




// Kalman Filter:
void Detector::predictionStep()
{
  //>>0. Prediction:
  for (int m = 0; m < balls_.size(); m++) {
    Ball bf = balls_[m];
    if (bf.getIsDetected()) { // Prediction
      bf.kfTimeUpdateStep(dt_);
    }
    balls_[m] = bf;
  }
  //<<0. Prediction
}

void Detector::correctionStep(std::vector<Ball> found_balls)
{
  //assigin and then correct.
  for (int a = 0; a < balls_.size(); a++) {
    Ball bb = balls_[a];
    bb.initBallVisibility();
    balls_[a] = bb;
  }

  //new ball or matched ball?
  if (balls_.size() == 0) {
    for (int m = 0; m < found_balls.size(); m++) { // all balls are new!
      Ball ff(found_balls[m].getDetectedBallPx(), found_balls[m].getCameraConstants(), found_balls[m].getSpecificAging());
      ff.initBall();
      ff.initDetectedBallInRelCoord(found_balls[m].getDetectedBallPx());
      ff.setIsNew(true);
      ff.setMatchedCount(0);
      balls_.push_back(ff);
      //std::cout<<"partic. ball x:"<<SSTR(ff.getDetectedBall().x)<<SSTR(balls_[0].getDetectedBall().x)<<std::endl;
      found_balls.erase(found_balls.begin() + m);
    }
  }

  else { //matched
    for (int m = 0; m < balls_.size(); m++) {
      Ball b = balls_[m]; // hier nicht balls cause when in else than ball index not exist!
      int l = checkBallInErrorEllipse(found_balls, b);
      if (!(l == -1)) { // is matched:
        cv::Point2f old = b.getDetectedBall();
        b.initDetectedBallInRelCoord(found_balls[l].getDetectedBallPx());
        cv::Point2f neu = b.getDetectedBall();
        //std::cout << "punkt neu: " << neu.x << " " << neu.y << " " << std::endl;
        b.setNotFoundCount(0);
        b.setMatchedCount(b.getMatchedCount() + 1);
        b.initMeas(old, neu, dt_);

        if (!b.getIsDetected()) {
          b.initErrorCov();
          b.initStates();
          b.setIsDetected(true);
        }
        else {
          b.kfCorrectionStep();
        }

        b.setIsMatched(true);
        balls_[m] = b;
        found_balls.erase(found_balls.begin() + l);
      }
    }
  }

  //new:
  for (int i = 0; i < found_balls.size(); i++) {
    Ball ff(found_balls[i].getDetectedBallPx(), found_balls[i].getCameraConstants(), found_balls[i].getSpecificAging());
    ff.initBall();
    ff.initDetectedBallInRelCoord(found_balls[i].getDetectedBallPx());
    ff.setIsNew(true);
    ff.setMatchedCount(0);
    balls_.push_back(ff);
    found_balls.erase(found_balls.begin() + i);
  }

  //unmatched balls:
  for (int a = 0; a < balls_.size(); a++) {
    if (!balls_[a].getIsNew() && !balls_[a].getIsMatched()) {
      balls_[a].setIsUnmatched(true);
    }
  }

  //>>>>>>>>>>>>>> Handle all balls:
  for (int u = 0; u < balls_.size(); u++) {
    Ball b = balls_[u];

    //A) Matched:
    if (b.getIsMatched()) {
      //see code above!
    }

    //B) New:
    if (b.getIsNew()) {
      b.initKalman(); //see functions in ball.h file!
      b.setNotFoundCount(0);
      b.initMeas(cv::Point2f(0, 0), cv::Point2f(0, 0), dt_);
      b.initErrorCov();
      b.initStates();
      b.setIsDetected(true);
      b.initErrorCircle();

      b.setLabel(balls_.size());
      int labell = balls_.size() - 1;
      for (int l = 0; l < balls_.size(); l++) {
        if (balls_[l].getLabel() == labell) {
          labell = labell + 1;
        }
      }
      b.setLabel(labell);
      balls_[u] = b;
    } // end is new

    //C) Occluded / unmatched:
    if (b.getIsUnmatched()) { //occluded balls:
      b.setNotFoundCount(b.getNotFoundCount() + 1);

      if (b.getNotFoundCount() >= 50) {
        b.setIsDetected(false);
      }

      if (b.getErrorEllipse().size.height > delete_ratio_) {
        balls_.erase(balls_.begin() + u);
      }
      else {
        balls_[u] = b;
      }
    } //end is occluded
  }
  //<<<<<<<< Handle all balls:
}




// helper functions:
bool Detector::pointInEllipse(float x, float y, float xp, float yp, float d, float D, float angle)
{
  //tests if a point[xp,yp] is within
  //boundaries defined by the ellipse
  //of center[x,y], diameter d D, and tilted at angle
  float cosa = cos(angle);
  float sina = sin(angle);
  float dd = d / 2 * d / 2;
  float DD = D / 2 * D / 2;

  float a = pow(cosa * (xp - x) + sina * (yp - y), 2);
  float b = pow(sina * (xp - x) - cosa * (yp - y), 2);
  float ell = (a / dd) + (b / DD);
  if (ell <= 1) {
    return true;
  }
  else {
    return false;
  }
}

int Detector::checkBallInErrorEllipse(std::vector<Ball> detected_balls, Ball b)
{
  //In relative coordinate system check if ball center point is within
  //an error circle!
  for (int l = 0; l < detected_balls.size(); l++) {
    //Convert found Ball to realtive domain
    cv::Point2f foundball = b.pxToCameraLinkCoord(detected_balls[l].getDetectedBallPx());
    cv::RotatedRect redrect = b.getErrorEllipse();

    if (pointInEllipse(redrect.center.x, redrect.center.y, foundball.x, foundball.y, redrect.size.height * 2, redrect.size.width * 2, redrect.angle)) {
      return l;
    }
  }
  //cout << "is a new ball" << endl<< endl;
  return -1;
}

} // end tb3 namespace.
