#include <turtlebot3_ball_tracking_exercise/ball.h>

namespace turtlebot3
{

//constructors:
Ball::Ball(cv::Point3d ball_px, std::vector<double> camera_constants, double specific_aging)
{
  //pass constants from parameter server:
   cc_=camera_constants;
   specific_aging_=specific_aging;

   // initialize some Ball Parameters:
   stateSize_ = 4;
   measSize_ = 4;
   error_factor_ = 1;

   detected_ball_px_=ball_px;
   detected_ball_ = pxToCameraLinkCoord(ball_px);
}

Ball::Ball()
{

}

// Kalman Filter:
void Ball::initKalman()
{
  unsigned int type = CV_32F;

  kf_ = cv::KalmanFilter(stateSize_, measSize_, 0, type);

  state_ = cv::Mat(stateSize_, 1, type); // [x,y,v_x,v_y]

  meas_ = (cv::Mat(measSize_, 1, type)); // [z_x,z_y]

  // Transition State Matrix A
  // Note: set dT at each processing step!
  // [ 1 0 dT 0  ]
  // [ 0 1 0  dT ]
  // [ 0 0 1  0  ]
  // [ 0 0 0  1  ]
  cv::setIdentity(kf_.transitionMatrix);

  // Measure Matrix H
  // [ 1 0 0 0 ]
  // [ 0 1 0 0 ]
  // [ 0 0 0 0 ]
  // [ 0 0 0 0 ]
  kf_.measurementMatrix = cv::Mat::zeros(measSize_, stateSize_, type);
  kf_.measurementMatrix.at<float>(0) = 1;
  kf_.measurementMatrix.at<float>(5) = 1;

  // Process Noise Covariance Matrix Q
  // [ Ex   0   0     0     ]
  // [ 0    Ey  0     0     ]
  // [ 0    0   Ev_x  0     ]
  // [ 0    0   0     Ev_y  ]
  kf_.processNoiseCov.at<float>(0) = 0.01;
  kf_.processNoiseCov.at<float>(5) = 0.01;
  kf_.processNoiseCov.at<float>(10) = 0.05;
  kf_.processNoiseCov.at<float>(15) = 0.05;

  // Measures Noise Covariance Matrix R
  cv::setIdentity(kf_.measurementNoiseCov, cv::Scalar(0.1));
}

void Ball::initMeas(cv::Point2f old_ball_position, cv::Point2f new_ball_position, float dT)
{
  //TODO: Check if this function is also executed if a
  //ball is refound after it was longer occluded
  //then its velocity is probably quite wrong!

  // fill meas vector with position values:
  meas_.at<float>(0) = (float)detected_ball_.x;
  meas_.at<float>(1) = (float)detected_ball_.y;

  // fill meas vector with new velocity values:
  float vzx = 1;
  if (new_ball_position.x < old_ball_position.x) {
    vzx = -1;
  }
  float vzy = 1;
  if (new_ball_position.y < old_ball_position.y) {
    vzy = -1;
  }

  meas_.at<float>(2) = vzx * (abs(new_ball_position.x - old_ball_position.x)) / dT; //vel in x:x-x/dT
  meas_.at<float>(3) = vzy * (abs(new_ball_position.y - old_ball_position.y)) / dT; //vel in y:y-y/dT
}

void Ball::initStates()
{
  state_.at<float>(0) = meas_.at<float>(0);
  state_.at<float>(1) = meas_.at<float>(1);
  state_.at<float>(2) = meas_.at<float>(2);
  state_.at<float>(3) = meas_.at<float>(3);
  kf_.statePost = state_;
}

void Ball::initErrorCov()
{
  // how to set this value? currently: 5cm
  kf_.errorCovPre.at<float>(0)  = 0.05;
  kf_.errorCovPre.at<float>(5)  = 0.05;
  kf_.errorCovPre.at<float>(10) = 0.05;
  kf_.errorCovPre.at<float>(15) = 0.05;
}

void Ball::kfCorrectionStep()
{
  kf_.correct(meas_);
}

void Ball::kfTimeUpdateStep(float dT)
{

  if ((matched_count_ <= 3 && not_found_count_ >= 1) || (not_found_count_ >= 1 && matched_count_ == 0))
  {
    error_factor_ = error_factor_ + specific_aging_;// nh.param<double>("ball_tracking/specific_aging", 5.0);
  }
  else
  {
    error_factor_ = 1;
  }

  kf_.transitionMatrix.at<float>(2) = dT;
  kf_.transitionMatrix.at<float>(7) = dT;

  state_ = kf_.predict();

  //update pink predicted rect:
  predicted_ball_.x = state_.at<float>(0);
  predicted_ball_.y = state_.at<float>(1);

  //update Error Rect:
  cv::Mat errorcovpic = kf_.errorCovPre;
  float errorxpic = (float)(errorcovpic.at<float>(0) + errorcovpic.at<float>(10) * dT); // in meter
  float errorypic = (float)(errorcovpic.at<float>(5) + errorcovpic.at<float>(15) * dT);

  error_ellipse_.center = cv::Point2f(predicted_ball_.x, predicted_ball_.y);
  error_ellipse_.size = cv::Size2f(errorxpic * 2 * error_factor_, errorypic * 2 * error_factor_);
  error_ellipse_.angle = 0.0;
}



// Ball Initialization methods:
void Ball::initErrorCircle()
{
  //cout << "init Error Rectm!" << endl;
  predicted_ball_ = detected_ball_;
  error_ellipse_.center = detected_ball_;
  error_ellipse_.size = cv::Size2f(0.1, 0.1);
}

void Ball::initBall()
{
  is_matched_ = false;
  is_unmatched_ = false;
  is_new_ = false;
  detected_ball_ = cv::Point2f(0, 0);
  error_ellipse_ = cv::RotatedRect(cv::Point2f(0, 0), cv::Size2f(0, 0), 0);
  predicted_ball_ = cv::Point2f(0, 0);
}

void Ball::initBallVisibility()
{
  //just reset bool values
  is_matched_ = false;
  is_unmatched_ = false;
  is_new_ = false;
}

void Ball::initDetectedBallInRelCoord(cv::Point3d ball_px)
{
  detected_ball_px_=ball_px;
  detected_ball_=pxToCameraLinkCoord(ball_px);
  //detected_ball_ = cv::Point2f(result_ray_.x, result_ray_.z);
}

// Pixel domain -> camera_link methods
cv::Point2f Ball::pxToCameraLinkCoord(cv::Point3d ball_px)
{
  double dis = getDistance((ball_px.z)*2);

  debug_params_.x=ball_px.x;
  debug_params_.y=ball_px.y;
  debug_params_.z=ball_px.z*2;
  getRay(ball_px.x, ball_px.y, dis);
  return cv::Point2f(result_ray_.x, result_ray_.z);
}

// Calculate the distance of the ball to the camera lense:
// 1) If you do not have the focus length of the camera:
//    -> First Calculate F = (P * D)  / W
//    -> next the distance can be calculated:
//    -> D' = (W*F)/P
//    (F: focus length
//     P: ball diameter in pixel measured at a certain distance D
//     W: real ball diameter in meters (ca. 0.064m))
// 2) The focus length might also be available in the camera_info F=(fx+fy)/2
// P=ballPixelRadius
// What is the difference between f and fx,fy? If fx=fy the pixels are completely quadratic
double Ball::getDistance(double ball_diameter_px)
{
  //TODO: Tune focus_length here!
  // according to Jerome focus_length = fx?!
  double ball_diameter = cc_.at(6); //[m]
  double focus_length = 618.75; // px or: f=(fx+fy)/2, ((cc_.at(0)+cc_.at(1)) / 2)
  return (ball_diameter * focus_length) / (ball_diameter_px); // [distance in meter]
}

// TODO: why is the y Position (often) positive. If ball on ground should be -4.5cm.
cv::Point3d Ball::getRay(double ball_middle_point_x, double ball_middle_point_y, double distance)
{
  // alternatively: use this whole package: http://wiki.ros.org/image_geometry/Tutorials/ProjectTfFrameToImage
  double cx = cc_.at(0); //px
  double cy = cc_.at(1); //px
  double fx = cc_.at(2); //px
  double fy = cc_.at(3); //px
  double Tx = cc_.at(4);
  double Ty = cc_.at(5);

  //TODO 480 aus camera_info rausholen.
  //bezug auf links unten von opencv daher diese konvertierung!
  ball_middle_point_y = 480.0 - ball_middle_point_y;

  result_ray_.z = distance; // [m]
  result_ray_.x = ((ball_middle_point_x - cx - Tx)*result_ray_.z) / fx; // [m]
  result_ray_.y = ((ball_middle_point_y - cy - Ty)*result_ray_.z) / fy; // [m]
  return result_ray_; // [m]
}



//Print methods:
std::string Ball::printBall()
{
  return "" + SSTR(label_) + ""
      + "f:" + SSTR(is_detected_) + ""
      + " n: " + SSTR(not_found_count_) + "" //not found count
      + " c: " + SSTR(matched_count_) + "" //found count
      + "|" + SSTR(is_new_)
      + "" + SSTR(is_matched_) + ""
      + "" + SSTR(is_unmatched_) + ""
      + "x: "+SSTR(ROUND2(result_ray_.x*100))+" "+SSTR(ROUND2(result_ray_.y*100))+" "+SSTR(ROUND2(result_ray_.z*100))
      + "| "+SSTR(ROUND2(debug_params_.x))+" "+SSTR(ROUND2(debug_params_.y))+" "+SSTR(ROUND2(debug_params_.z));
//  + " |g:(" + SSTR(ROUND2(detected_ball_.x)) + "," + SSTR(ROUND2(detected_ball_.y)) + ")"
//  + " p:(" + SSTR(ROUND2(predicted_ball_.x)) + "," + SSTR(ROUND2(predicted_ball_.y)) + ")"
      // + " r:(" + SSTR(ROUND2(error_ellipse_.center.x)) + "," + SSTR(ROUND2(error_ellipse_.center.y)) + "," + SSTR(ROUND2(error_ellipse_.size.width * 100)) + "," + SSTR(ROUND2(error_ellipse_.size.height * 100)) + ")";
}

std::string Ball::printState()
{
  return "" + SSTR(label_) + ""
      + " x:" + SSTR(ROUND2(state_.at<float>(0))) + ""
      + " y:" + SSTR(ROUND2(state_.at<float>(1))) + ""
      + " |vx:" + SSTR(ROUND2(state_.at<float>(2))) + ""
      + " vy:" + SSTR(ROUND2(state_.at<float>(3)));
}

} //end namespace.
